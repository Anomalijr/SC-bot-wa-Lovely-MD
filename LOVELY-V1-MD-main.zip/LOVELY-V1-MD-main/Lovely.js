{
	"name": "Lovely Bot Multi Device "
}