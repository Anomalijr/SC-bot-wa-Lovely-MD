
//══════════════════════════════════════════════════════════════════════════════════════════════════════//
//                                                                                                      //
//                                 𝐗𝐋𝐈𝐂𝐎𝐍-𝐕𝟑-𝐌𝐃    𝐁𝐎𝐓                                                //
//                                                                                                      // 
//                                         Ｖ：3.0                                                      // 
//                                                                                                      // 
//              ██╗  ██╗██╗     ██╗ ██████╗ ██████╗ ███╗   ██╗      ██╗   ██╗██████╗                    //
//              ╚██╗██╔╝██║     ██║██╔════╝██╔═══██╗████╗  ██║      ██║   ██║╚════██╗                   //
//                ╚███╔╝ ██║     ██║██║     ██║   ██║██╔██╗ ██║█████╗██║   ██║ █████╔╝                  //
//               ██╔██╗ ██║     ██║██║     ██║   ██║██║╚██╗██║╚════╝╚██╗ ██╔╝ ╚═══██╗                   //
//              ██╔╝ ██╗███████╗██║╚██████╗╚██████╔╝██║ ╚████║       ╚████╔╝ ██████╔╝                   //
//              ╚═╝  ╚═╝╚══════╝╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝        ╚═══╝  ╚═════╝                    //
//                                                                                                      //
//                                                                                                      //
//                                                                                                      //
//══════════════════════════════════════════════════════════════════════════════════════════════════════//
//*
 //  * @project_name : XLICON-V3-MD
 //  * @author : salmanytofficial
 //  * @youtube : https://www.youtube.com/@s4salmanyt
//   * @description : XLICON-V3 ,A Multi-functional whatsapp user bot.
//*
//* 
//base by DGXeon
//re-upload? recode? copy code? give credit ya :)
//Instagram: unicorn_xeon13
//Telegram: t.me/ahmmitech
//GitHub: @salmanytofficial
//WhatsApp: +923184070915
//want more free bot scripts? subscribe to my youtube channel: https://youtube.com/@DGXeon
//   * Created By Github: DGXeon.
//   * Credit To Xeon
//   * © 2024 XLICON-V3-MD.
// ⛥┌┤
// */

const _0x23da1c=_0x4f4e;(function(_0x51691a,_0x41ba3d){const _0x342e45=_0x4f4e,_0x3f1151=_0x51691a();while(!![]){try{const _0x1e42aa=-parseInt(_0x342e45(0x1d2))/0x1*(parseInt(_0x342e45(0x1d4))/0x2)+-parseInt(_0x342e45(0x1d1))/0x3+parseInt(_0x342e45(0x1c1))/0x4*(parseInt(_0x342e45(0x1c9))/0x5)+-parseInt(_0x342e45(0x1ca))/0x6+-parseInt(_0x342e45(0x1c8))/0x7*(-parseInt(_0x342e45(0x1c5))/0x8)+-parseInt(_0x342e45(0x1cf))/0x9*(-parseInt(_0x342e45(0x1d3))/0xa)+parseInt(_0x342e45(0x1bd))/0xb*(parseInt(_0x342e45(0x1d5))/0xc);if(_0x1e42aa===_0x41ba3d)break;else _0x3f1151['push'](_0x3f1151['shift']());}catch(_0x32f910){_0x3f1151['push'](_0x3f1151['shift']());}}}(_0x2fff,0x4ba8e));function _0x4f4e(_0x168980,_0x1e94a6){const _0x2fff69=_0x2fff();return _0x4f4e=function(_0x4f4ec4,_0x557541){_0x4f4ec4=_0x4f4ec4-0x1bd;let _0x2d4897=_0x2fff69[_0x4f4ec4];return _0x2d4897;},_0x4f4e(_0x168980,_0x1e94a6);}function _0x2fff(){const _0xec35e6=['exit','error','child_process','3948LMVlZD','path','argv','ipc','16CuAjIW','log','kill','2083914fvxjja','1335bkVbiz','1990404OKTqJE','Restarting\x20Bot...','inherit','Exited\x20with\x20code:','join','168534gzDItM','reset','1744632mpvHCM','185137UzvQnY','290GnAtSx','4RJthmF','2297604uzejzp','slice','message','11NKqsgg'];_0x2fff=function(){return _0xec35e6;};return _0x2fff();}const {spawn}=require(_0x23da1c(0x1c0)),path=require(_0x23da1c(0x1c2));function start(){const _0x2202e0=_0x23da1c;let _0x25d0b9=[path[_0x2202e0(0x1ce)](__dirname,'main.js'),...process[_0x2202e0(0x1c3)][_0x2202e0(0x1d6)](0x2)];console[_0x2202e0(0x1c6)]([process['argv'][0x0],..._0x25d0b9][_0x2202e0(0x1ce)]('\x0a'));let _0x34cef9=spawn(process[_0x2202e0(0x1c3)][0x0],_0x25d0b9,{'stdio':[_0x2202e0(0x1cc),_0x2202e0(0x1cc),_0x2202e0(0x1cc),_0x2202e0(0x1c4)]})['on'](_0x2202e0(0x1d7),_0x35585a=>{const _0x279732=_0x2202e0;_0x35585a==_0x279732(0x1d0)&&(console[_0x279732(0x1c6)](_0x279732(0x1cb)),_0x34cef9[_0x279732(0x1c7)](),start(),delete _0x34cef9);})['on'](_0x2202e0(0x1be),_0x46de0f=>{const _0x14aecc=_0x2202e0;console[_0x14aecc(0x1bf)](_0x14aecc(0x1cd),_0x46de0f);if(_0x46de0f=='.'||_0x46de0f==0x1||_0x46de0f==0x0)start();});}start();
