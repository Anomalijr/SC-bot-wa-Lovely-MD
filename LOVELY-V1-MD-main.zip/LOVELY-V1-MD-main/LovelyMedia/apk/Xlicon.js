{
	"name": "Xlicon Bot Multi Device "
}